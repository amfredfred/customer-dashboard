import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TradeRelay",
  description: "Private signal access and local MT5 execution.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
