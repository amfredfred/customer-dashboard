"use client";

import { createBrowserSupabase } from "@/lib/supabase";
import { useCallback, useEffect, useMemo, useState } from "react";

type EngineDevice = {
  id: string;
  license_id: string;
  engine_id: string;
  device_name: string;
  platform: Record<string, unknown>;
  engine_version: string;
  status: string;
  activated_at: string;
  last_seen_at: string | null;
};

type License = {
  id: string;
  status: string;
  max_devices: number;
  expires_at: string | null;
};

type EngineSession = {
  engine_device_id: string;
  connected_at: string;
  disconnected_at: string | null;
  disconnect_reason: string | null;
  last_heartbeat_at: string | null;
};

type EngineView = EngineDevice & {
  license?: License;
  symbols: string[];
  session?: EngineSession;
  usedSlots: number;
};

const OFFLINE_AFTER_MS = 90_000;

function isOnline(engine: EngineView, nowMs: number) {
  const heartbeat = engine.session?.last_heartbeat_at;
  return Boolean(
    engine.status === "active" &&
    engine.license?.status === "active" &&
    engine.session &&
    !engine.session.disconnected_at &&
    heartbeat &&
    nowMs > 0 &&
    nowMs - Date.parse(heartbeat) <= OFFLINE_AFTER_MS,
  );
}

function platformLabel(platform: Record<string, unknown>) {
  return [platform.os, platform.architecture].filter(Boolean).map(String).join(" ") || "Platform unavailable";
}

function timeAgo(value: string | null | undefined, nowMs: number) {
  if (!value) return "Never";
  if (!nowMs) return "Checking...";
  const seconds = Math.max(0, Math.floor((nowMs - Date.parse(value)) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

export default function Engines() {
  const supabase = useMemo(() => createBrowserSupabase(), []);
  const [engines, setEngines] = useState<EngineView[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nowMs, setNowMs] = useState(0);

  const load = useCallback(async () => {
    if (!supabase) {
      setError("Supabase is not configured");
      setLoading(false);
      return;
    }

    const devicesResult = await supabase
      .from("engine_devices")
      .select("id,license_id,engine_id,device_name,platform,engine_version,status,activated_at,last_seen_at")
      .order("activated_at", { ascending: false });
    if (devicesResult.error) {
      setError(devicesResult.error.message);
      setLoading(false);
      return;
    }

    const devices = (devicesResult.data ?? []) as EngineDevice[];
    const licenseIds = [...new Set(devices.map(device => device.license_id))];
    const deviceIds = devices.map(device => device.id);

    const [licensesResult, entitlementsResult, sessionsResult] = await Promise.all([
      licenseIds.length
        ? supabase.from("licenses").select("id,status,max_devices,expires_at").in("id", licenseIds)
        : Promise.resolve({ data: [], error: null }),
      licenseIds.length
        ? supabase.from("license_symbol_entitlements").select("license_id,symbol").in("license_id", licenseIds)
        : Promise.resolve({ data: [], error: null }),
      deviceIds.length
        ? supabase.from("engine_sessions").select("engine_device_id,connected_at,disconnected_at,disconnect_reason,last_heartbeat_at").in("engine_device_id", deviceIds).order("connected_at", { ascending: false })
        : Promise.resolve({ data: [], error: null }),
    ]);

    const queryError = licensesResult.error ?? entitlementsResult.error ?? sessionsResult.error;
    if (queryError) {
      setError(queryError.message);
      setLoading(false);
      return;
    }

    const licenses = new Map((licensesResult.data as License[]).map(license => [license.id, license]));
    const symbolsByLicense = new Map<string, string[]>();
    for (const item of entitlementsResult.data as { license_id: string; symbol: string }[]) {
      symbolsByLicense.set(item.license_id, [...(symbolsByLicense.get(item.license_id) ?? []), item.symbol]);
    }
    const sessions = new Map<string, EngineSession>();
    for (const session of sessionsResult.data as EngineSession[]) {
      if (!sessions.has(session.engine_device_id)) sessions.set(session.engine_device_id, session);
    }
    const slotsByLicense = new Map<string, number>();
    for (const device of devices) slotsByLicense.set(device.license_id, (slotsByLicense.get(device.license_id) ?? 0) + 1);

    setEngines(devices.map(device => ({
      ...device,
      license: licenses.get(device.license_id),
      symbols: symbolsByLicense.get(device.license_id) ?? [],
      session: sessions.get(device.id),
      usedSlots: slotsByLicense.get(device.license_id) ?? 0,
    })));
    setError(null);
    setLoading(false);
  }, [supabase]);

  useEffect(() => {
    const initialTimer = setTimeout(() => void load(), 0);
    const dataTimer = setInterval(() => void load(), 30_000);
    const updateClock = () => setNowMs(Date.now());
    updateClock();
    const clockTimer = setInterval(updateClock, 10_000);
    return () => {
      clearTimeout(initialTimer);
      clearInterval(dataTimer);
      clearInterval(clockTimer);
    };
  }, [load]);

  return (
    <div className="p-5 md:p-8 max-w-6xl mx-auto">
      <div className="text-xs uppercase tracking-[.17em] muted">Installed engines</div>
      <h1 className="text-3xl font-semibold mt-3">Engines</h1>
      <p className="muted mt-2 text-sm">Owned installations and their latest Gateway session heartbeat.</p>

      {loading && <div className="panel mt-8 p-5 muted text-sm">Loading owned engines...</div>}
      {error && <div className="panel mt-8 p-5 text-sm text-[#f43f5e]">{error}</div>}
      {!loading && !error && engines.length === 0 && <div className="panel mt-8 p-5 muted text-sm">No activated execution engines.</div>}

      <div className="mt-8 space-y-4">
        {engines.map(engine => {
          const online = isOnline(engine, nowMs);
          const maxDevices = engine.license?.max_devices ?? 0;
          return (
            <section key={engine.id} className="panel overflow-hidden">
              <div className="p-5 border-b border-white/[.07] flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div>
                  <div className="font-semibold">{engine.engine_id}</div>
                  <div className="text-xs muted mt-1">{engine.device_name} · {platformLabel(engine.platform)}</div>
                </div>
                <span className="pill">
                  <span className={`w-1.5 h-1.5 rounded-full ${online ? "bg-[#3ddc97]" : "bg-[#f5b942]"}`} />
                  {online ? "Online" : "Offline"}
                </span>
              </div>
              <div className="p-5 grid sm:grid-cols-2 lg:grid-cols-4 gap-5 text-sm">
                <div><div className="muted text-xs">Version</div><div className="mt-2 mono">{engine.engine_version}</div></div>
                <div><div className="muted text-xs">Symbols</div><div className="mt-2 mono">{engine.symbols.join(", ") || "None"}</div></div>
                <div><div className="muted text-xs">Device slots</div><div className="mt-2 mono">{engine.usedSlots} of {maxDevices || "--"}</div></div>
                <div><div className="muted text-xs">Last heartbeat</div><div className="mt-2 mono">{timeAgo(engine.session?.last_heartbeat_at ?? engine.last_seen_at, nowMs)}</div></div>
              </div>
              {!online && engine.session?.disconnect_reason && (
                <div className="px-5 pb-5 text-xs muted">Last disconnect: {engine.session.disconnect_reason}</div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
