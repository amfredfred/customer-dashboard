"use client";

import { DataTable, DetailSection, EmptyTable, Metric, MetricGrid, StreamBanner } from "@/components/metric-detail";
import { useGateway } from "@/components/gateway-provider";
import { useEffect } from "react";

export default function Execution() {
  const gateway = useGateway();
  const { setExecutionMetricsEngine } = gateway;
  const engineId = process.env.NEXT_PUBLIC_EXECUTION_ENGINE_ID ?? "execution-local-106189638";
  useEffect(() => {
    setExecutionMetricsEngine(engineId);
    return () => setExecutionMetricsEngine(null);
  }, [engineId, setExecutionMetricsEngine]);
  const snapshot = gateway.executionMetrics;
  const metrics = snapshot?.metrics ?? {};
  const number = (key: string) => typeof metrics[key] === "number" ? metrics[key] as number : undefined;
  const count = (key: string) => number(key)?.toLocaleString("en-US") ?? "--";
  const money = (key: string) => number(key) === undefined ? "--" : `$${number(key)!.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const pct = (key: string) => number(key) === undefined ? "--" : `${number(key)!.toFixed(2)}%`;
  const ms = (key: string) => number(key) === undefined ? "--" : `${number(key)!.toLocaleString("en-US")}ms`;
  const notTracked = "Not tracked";
  const trades = snapshot?.trades ?? [];
  const signals = snapshot?.signals ?? [];
  return (
    <div className="p-5 md:p-8 max-w-[1680px] mx-auto space-y-5">
      <div>
        <div className="text-xs uppercase tracking-[.17em] muted">Private execution domain</div>
        <h1 className="text-3xl font-semibold mt-3">My Execution</h1>
        <p className="muted mt-2 text-sm">Owner-scoped account, risk, trade, and broker execution telemetry from your installed engine.</p>
      </div>

      <StreamBanner domain="execution.metrics" ready={Boolean(snapshot)} status={gateway.executionMetricsError ?? undefined}>
        Select an owned engine to request its private stream. The Gateway verifies ownership before forwarding any account data.
      </StreamBanner>

      <DetailSection title="Account Snapshot" subtitle="Current broker account state">
        <MetricGrid>
          <Metric label="Balance" value={money("balance")} detail={String(metrics.currency ?? "Account currency")} />
          <Metric label="Equity" value={money("equity")} detail={`Peak ${money("peak_equity")}`} />
          <Metric label="Daily P&L" value={money("daily_pnl")} />
          <Metric label="Max Drawdown" value={pct("drawdown_pct")} />
          <Metric label="Free Margin" value={money("free_margin")} />
          <Metric label="Margin Level" value={pct("margin_level")} />
          <Metric label="Commission Paid" value={notTracked} detail="Requires broker history aggregation" />
          <Metric label="Unrealized P&L" value={money("net_pnl")} />
        </MetricGrid>
      </DetailSection>

      <DetailSection title="Risk State" subtitle="Live limits and available execution capacity">
        <MetricGrid>
          <Metric label="Daily Budget" value={money("daily_budget")} />
          <Metric label="Budget Used" value={money("daily_budget_used")} />
          <Metric label="Budget Left" value={money("daily_budget_left")} />
          <Metric label="Risk Per Trade" value={money("risk_per_trade")} />
          <Metric label="Daily Loss" value={pct("daily_loss_pct")} />
          <Metric label="Daily Loss Limit" value={pct("daily_loss_limit_percent")} />
          <Metric label="Risk Slots" value={count("risk_slots")} />
          <Metric label="Max Losing Streak" value={count("max_losing_streak")} />
        </MetricGrid>
      </DetailSection>

      <div className="grid xl:grid-cols-2 gap-5">
        <DetailSection title="Execution Flow" badge="orders">
          <MetricGrid>
            <Metric label="Open Trades" value={count("open_trades")} />
            <Metric label="Trades Today" value={count("total_trades_today")} />
            <Metric label="Orders Filled" value={count("orders_filled")} />
            <Metric label="Orders Rejected" value={count("orders_rejected")} />
            <Metric label="Orders Retried" value={count("orders_retried")} />
            <Metric label="Partial Fills" value={count("orders_partial_fills")} />
            <Metric label="Slippage Rejected" value={count("orders_slippage_rejected")} />
            <Metric label="Emergency Closes" value={count("orders_emergency_closes")} />
          </MetricGrid>
        </DetailSection>
        <DetailSection title="Signal Handling" badge="engine intake">
          <MetricGrid>
            <Metric label="Signals Received" value={count("signals_received")} />
            <Metric label="Signals Triggered" value={count("signals_triggered")} />
            <Metric label="Validation Rejected" value={count("signals_validation_failures")} />
            <Metric label="Risk Approved" value={count("risk_approved")} />
            <Metric label="Risk Rejected" value={count("risk_rejected")} />
            <Metric label="Trades Opened" value={count("trades_opened")} />
            <Metric label="Duplicates Ignored" value={count("signal_duplicates_ignored")} />
            <Metric label="Pending Signals" value={count("pending_signals")} />
          </MetricGrid>
        </DetailSection>
      </div>

      <div className="grid xl:grid-cols-2 gap-5">
        <DetailSection title="Execution Latency" subtitle="End-to-end delivery and broker timing">
          <MetricGrid>
            <Metric label="Signal-to-Trade" value={ms("latency_signal_to_trade_ms")} />
            <Metric label="Signal Age" value={ms("latency_market_signal_age_ms")} />
            <Metric label="Emit-to-Receive" value={ms("latency_emit_to_receive_ms")} />
            <Metric label="Receive-to-Execute" value={ms("latency_receive_to_execute_ms")} />
            <Metric label="Execution Pipeline" value={ms("latency_execution_pipeline_ms")} />
            <Metric label="Broker Round Trip" value={ms("latency_broker_round_trip_ms")} />
            <Metric label="Average Slippage" value={notTracked} />
            <Metric label="Average Spread" value={notTracked} />
          </MetricGrid>
        </DetailSection>
        <DetailSection title="Trade Outcomes" subtitle="Private results from this account">
          <MetricGrid>
            <Metric label="Winning Trades" value={count("winning_trades")} />
            <Metric label="Losing Trades" value={count("losing_trades")} />
            <Metric label="Win Rate" value={pct("win_rate")} />
            <Metric label="Profit Factor" value={notTracked} />
            <Metric label="Average R:R" value={notTracked} />
            <Metric label="Executed R:R" value={notTracked} />
            <Metric label="TP Hits" value={(number("trades_tp1_hit") ?? 0) + (number("trades_tp2_hit") ?? 0) + ""} />
            <Metric label="SL Hits" value={count("trades_sl_hit")} />
          </MetricGrid>
        </DetailSection>
      </div>

      <DetailSection title="Open Positions" subtitle="Only positions belonging to the selected account" badge="private">
        <DataTable
          columns={["Ticket", "Symbol", "Side", "Size", "Entry", "SL", "TP", "P&L", "State"]}
          rows={trades.map(trade => [
            String(trade.ticket ?? "--"),
            String(trade.symbol ?? "--"),
            String(trade.side ?? "--"),
            String(trade.lots ?? "--"),
            String(trade.entry_price ?? "--"),
            String(trade.sl ?? "--"),
            String(trade.tp2 ?? trade.tp1 ?? "--"),
            String(trade.pnl ?? "--"),
            String(trade.state ?? "--"),
          ])}
          emptyMessage="No open positions."
        />
      </DetailSection>

      <div className="grid xl:grid-cols-2 gap-5">
        <DetailSection title="Recent Signals" subtitle="Signals received by this execution engine">
          <DataTable
            columns={["Time", "Symbol", "Side", "Strategy", "Status"]}
            rows={signals.map(signal => [
              String(signal.timestamp ?? "--"),
              String(signal.symbol ?? "--"),
              String(signal.direction ?? "--"),
              String(signal.strategy ?? "--"),
              String(signal.status ?? "--"),
            ])}
            emptyMessage="No recent execution signal events."
          />
        </DetailSection>
        <DetailSection title="Order Activity" subtitle="Fills, closes, partial exits and failures">
          <EmptyTable columns={["Time", "Event", "Ticket", "Symbol", "Price", "P&L"]} message="No order activity received." />
        </DetailSection>
      </div>
    </div>
  );
}
