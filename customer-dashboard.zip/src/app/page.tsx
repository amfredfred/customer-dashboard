import { ArrowRight, RadioTower, ShieldCheck, TerminalSquare } from "lucide-react";
import Link from "next/link";

const plans = [
  ["Standard", "$49", "1 execution engine", "Private signal access", "Core risk controls"],
  ["Multi-Account", "$129", "Up to 5 engines", "Consolidated monitoring", "Account-specific risk"],
  ["Prop Firm", "Custom", "Strict drawdown controls", "Rule templates", "Priority diagnostics"],
];

export default function Home() {
  return <main>
    <header className="h-16 max-w-7xl mx-auto px-5 flex items-center justify-between">
      <div className="font-bold tracking-[.18em] text-sm">TRADERELAY</div>
      <nav className="flex items-center gap-5 text-sm"><a href="#pricing" className="muted">Pricing</a><Link href="/login" className="pill">Sign in <ArrowRight size={12}/></Link></nav>
    </header>
    <section className="max-w-7xl mx-auto px-5 pt-24 pb-28 grid lg:grid-cols-[1.15fr_.85fr] gap-14 items-center">
      <div><div className="pill"><RadioTower size={12}/> Private signals. Local execution.</div>
        <h1 className="mt-7 text-5xl md:text-7xl font-semibold tracking-[-.055em] leading-[.98]">TradeRelay keeps execution close to your account.</h1>
        <p className="mt-7 text-lg muted max-w-2xl leading-8">Our private signal infrastructure routes opportunities to your licensed Execution Engine. Your local risk controls make the final decision beside MetaTrader 5.</p>
        <div className="mt-9 flex gap-3"><Link href="/login" className="bg-[#3ddc97] text-black font-semibold rounded-lg px-5 py-3 text-sm">Continue securely</Link><Link href="/app/signals" className="panel px-5 py-3 text-sm">View signal performance</Link></div>
      </div>
      <div className="panel p-5 md:p-7">
        <div className="flex justify-between items-center"><span className="text-xs muted uppercase tracking-widest">Architecture</span><span className="pill"><span className="w-1.5 h-1.5 bg-[#3ddc97] rounded-full"/> Live</span></div>
        <div className="mt-8 space-y-3">
          {[["Private Signal Engine","TradeRelay infrastructure",RadioTower],["Execution Gateway","Licensed routing and control",ShieldCheck],["Your Execution Engine","Local MT5 and risk authority",TerminalSquare]].map(([title, detail, Icon]) => <div key={String(title)} className="bg-white/[.03] border border-white/[.07] rounded-xl p-4 flex gap-4 items-center"><Icon size={18} className="text-[#3ddc97]"/><div><div className="text-sm font-semibold">{String(title)}</div><div className="text-xs muted mt-1">{String(detail)}</div></div></div>)}
        </div>
      </div>
    </section>
    <section id="pricing" className="max-w-7xl mx-auto px-5 pb-28"><div className="text-xs uppercase tracking-[.2em] muted">Pricing</div><h2 className="mt-4 text-4xl font-semibold tracking-tight">Start with one account. Scale deliberately.</h2>
      <div className="grid md:grid-cols-3 gap-4 mt-10">{plans.map(([name, price, ...features]) => <div key={name} className="panel p-6"><div className="text-sm font-semibold">{name}</div><div className="text-4xl font-semibold mt-5">{price}<span className="text-sm muted">{price.startsWith("$") ? "/mo" : ""}</span></div><div className="mt-7 space-y-3">{features.map(x => <div key={x} className="text-sm muted flex gap-2"><ShieldCheck size={14} className="text-[#3ddc97] mt-0.5"/>{x}</div>)}</div><Link href="/login" className="mt-8 block text-center rounded-lg border border-white/10 py-3 text-sm">Choose {name}</Link></div>)}</div>
    </section>
  </main>;
}
